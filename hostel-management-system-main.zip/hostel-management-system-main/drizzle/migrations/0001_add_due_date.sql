-- Add due_date column to fee_structures table
ALTER TABLE fee_structures ADD COLUMN due_date DATE; 